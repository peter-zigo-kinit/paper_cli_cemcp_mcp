# filesystem.list_directory_with_sizes

Get a detailed listing of all files and directories in a specified path, including sizes. Results clearly distinguish between files and directories with [FILE] and [DIR] prefixes. This tool is useful for understanding directory structure and finding specific files within a directory. Only works within allowed directories.

## Input Schema
```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "path": {
      "type": "string"
    },
    "sortBy": {
      "default": "name",
      "description": "Sort entries by name or size",
      "type": "string",
      "enum": [
        "name",
        "size"
      ]
    }
  },
  "required": [
    "path"
  ]
}
```

## Example Usage
```python
mcp_call_http(name="filesystem.list_directory_with_sizes", args={"path": "<string>", "sortBy": "<string>"})
```
